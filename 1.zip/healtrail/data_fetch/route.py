from flask import Flask, render_template, request, redirect, url_for
from flask import Blueprint
from flask_mysqldb import MySQLdb,MySQL
# package contains flsk blueprint and mysqldb to help me 
mysql=MySQL()
data_fetch= Blueprint('data_fetch',__name__)
@data_fetch.route('/medicine_unit',methods=['GET','POST'])
def data_fetch():
    cur= mysql.connection.cursor()
    cur.execute("SELECT* FROM master_unit")
    cur.fetchall()
    return render_template('data_fetch/medicine_unit.html')
