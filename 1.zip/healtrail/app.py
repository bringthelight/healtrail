from flask import Flask

from auth.routes import auth
from dash.routes import dash
from flask_mysqldb import MySQL
from data_fetch.route import data_fetch
app=Flask(__name__,template_folder='templates/',static_folder='static/',static_url_path='/')

app.register_blueprint(auth)
app.register_blueprint(dash)
app.register_blueprint(data_fetch)
mysql=MySQL(app)
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'healtrail_pharmacy'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'



if __name__=='__main__':
    app.run(debug=True)